// @ts-ignore
import { runApp } from 'rax-app';

/** h5调试工具，生产环境请自行删除 */
import eruda from 'eruda';

eruda.init();

runApp({});
