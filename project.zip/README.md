# @aligov/h5-rax-scaffold

## 开始使用

### `npm run start`

开发模式下运行应用

通过打开浏览器访问 [http://localhost:3333](http://localhost:3333) 进行调试
在修改代码保存后，页面会自动重载。

### `npm run build`

编译代码，编译后的工程

## 查看文档

Rax 官网[https://rax.js.org/](https://rax.js.org/)
