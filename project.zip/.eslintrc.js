module.exports = {
  extends: ['rax']
};