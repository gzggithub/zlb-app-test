import { IAppConfig } from './types';

function loadStaticModules(appConfig: IAppConfig) {}

export default loadStaticModules;
